import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { LowSync, JSONFileSync } from 'lowdb'
import { join } from 'path'

const router = Router()
const adapter = new JSONFileSync(join(__dirname,'..','db.json'))
const db = new LowSync(adapter)
db.read()
if(!db.data) db.data = { users: [] }

const JWT_SECRET = process.env.JWT_SECRET || 'change-me'

router.post('/signup', async (req,res)=>{
  const { email, password } = req.body
  if(!email || !password) return res.status(400).send({ message: 'missing fields' })
  db.read()
  const exists = db.data!.users.find((u:any)=>u.email === email)
  if(exists) return res.status(400).send({ message: 'user exists' })
  const hash = await bcrypt.hash(password, 10)
  const user = { id: Date.now().toString(), email, password: hash }
  db.data!.users.push(user)
  db.write()
  res.status(201).send({ ok: true })
})

router.post('/login', async (req,res)=>{
  const { email, password } = req.body
  if(!email || !password) return res.status(400).send({ message: 'missing fields' })
  db.read()
  const user = db.data!.users.find((u:any)=>u.email === email)
  if(!user) return res.status(401).send({ message: 'invalid credentials' })
  const ok = await bcrypt.compare(password, user.password)
  if(!ok) return res.status(401).send({ message: 'invalid credentials' })
  const token = jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' })
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' })
  res.send({ ok: true })
})

export default router
