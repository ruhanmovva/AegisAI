import { Router } from 'express'
import multer from 'multer'
import path from 'path'
import OpenAI from 'openai'
import jwt from 'jsonwebtoken'

const router = Router()
const upload = multer({ dest: path.join(__dirname,'..','uploads/') })
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
const JWT_SECRET = process.env.JWT_SECRET || 'change-me'

function authMiddleware(req:any,res:any,next:any){
  try{
    const token = req.cookies?.token
    if(!token) return res.status(401).send({ message: 'unauth' })
    const payload = jwt.verify(token, JWT_SECRET)
    req.user = payload
    next()
  }catch(e){ return res.status(401).send({ message: 'unauth' }) }
}

router.post('/vision', authMiddleware, upload.single('image'), async (req:any,res)=>{
  if(!req.file) return res.status(400).send({ message: 'no file' })
  try{
    res.send({ received: true, filename: req.file.originalname })
  }catch(err:any){ res.status(500).send({ message: err.message }) }
})

router.post('/chat', authMiddleware, async (req,res)=>{
  const { prompt } = req.body
  if(!prompt) return res.status(400).send({ message: 'missing prompt' })
  try{
    const response = await client.chat.completions.create({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }], max_tokens: 500 })
    res.send(response)
  }catch(err:any){ res.status(500).send({ message: err.message }) }
})

export default router
