import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import authRoutes from './routes/auth'
import openaiRoutes from './routes/openai'
import dotenv from 'dotenv'

dotenv.config()
const app = express()
const PORT = process.env.PORT || 4000

app.use(express.json())
app.use(cookieParser())
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173', credentials: true }))

app.use('/api/auth', authRoutes)
app.use('/api/openai', openaiRoutes)

app.get('/api/auth/me', (req,res)=>{
  const token = (req as any).cookies?.token
  if(!token) return res.status(401).send({ message: 'not authenticated' })
  res.send({ authenticated: true })
})

app.listen(PORT, ()=> console.log('API listening on', PORT))
