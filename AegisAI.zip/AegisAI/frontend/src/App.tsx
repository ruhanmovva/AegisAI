import React from 'react'
import Login from './components/Login'
import Signup from './components/Signup'
import Dashboard from './components/Dashboard'

export default function App(){
  const [mode, setMode] = React.useState<'login'|'signup'|'dashboard'>('login')
  const [authed, setAuthed] = React.useState(false)

  React.useEffect(()=>{
    fetch('/api/auth/me', { credentials: 'include' })
      .then(r=>{ if(r.ok){ setAuthed(true); setMode('dashboard') }})
  },[])

  if(authed) return <Dashboard />
  return (
    <div className="p-8 max-w-3xl mx-auto">
      <header className="flex items-center justify-between mb-6">
        <img src="/logo.svg" alt="AegisAI logo" width={56} />
        <div>
          <button onClick={()=>setMode('login')} className="mr-2">Login</button>
          <button onClick={()=>setMode('signup')}>Sign up</button>
        </div>
      </header>
      {mode === 'login' ? <Login onSuccess={()=>setAuthed(true)} /> : <Signup onSuccess={()=>setMode('login')} />}
    </div>
  )
}
