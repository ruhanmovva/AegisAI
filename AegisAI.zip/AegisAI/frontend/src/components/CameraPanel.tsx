import React from 'react'
import axios from 'axios'

export default function CameraPanel(){
  const videoRef = React.useRef<HTMLVideoElement|null>(null)
  const [stream, setStream] = React.useState<MediaStream | null>(null)

  React.useEffect(()=>{
    async function start(){
      try{
        const s = await navigator.mediaDevices.getUserMedia({ video: true, audio:false })
        setStream(s)
        if(videoRef.current) videoRef.current.srcObject = s
      }catch(e){ console.error('camera error', e) }
    }
    start()
    return ()=>{ stream?.getTracks().forEach(t=>t.stop()) }
  },[])

  async function capture(){
    if(!videoRef.current) return
    const video = videoRef.current
    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    const ctx = canvas.getContext('2d')!
    ctx.drawImage(video, 0, 0)
    const blob = await new Promise<Blob | null>(res=>canvas.toBlob(res,'image/jpeg'))
    if(!blob) return
    const fd = new FormData()
    fd.append('image', blob, 'capture.jpg')
    await axios.post('/api/openai/vision', fd, { withCredentials: true, headers: {'Content-Type':'multipart/form-data'} })
  }

  return (
    <div>
      <h3>Camera</h3>
      <video ref={videoRef} autoPlay muted playsInline style={{width:'100%'}} />
      <button onClick={capture}>Capture & send to AI</button>
    </div>
  )
}
