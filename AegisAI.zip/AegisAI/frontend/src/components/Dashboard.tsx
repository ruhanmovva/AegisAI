import React from 'react'
import CameraPanel from './CameraPanel'
import VoiceAgent from './VoiceAgent'

export default function Dashboard(){
  return (
    <div>
      <h1 className="text-2xl mb-4">AegisAI Dashboard</h1>
      <div className="grid grid-cols-2 gap-4">
        <CameraPanel />
        <div><VoiceAgent /></div>
      </div>
    </div>
  )
}
