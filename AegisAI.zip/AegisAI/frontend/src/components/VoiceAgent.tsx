import React from 'react'

export default function VoiceAgent(){
  return (
    <div>
      <h2>Voice Assistant</h2>
      <iframe id="audio_iframe" src="https://widget.synthflow.ai/widget/v2/99b77c4a-3dbb-4e4b-957f-a8269a57439e/1760295755028x966151390794587400" allow="microphone" width="400px" height="550px" pointer-events="none" scrolling="no" style={{position:'fixed', background:'transparent', border:'none', zIndex:999}}></iframe>
    </div>
  )
}
