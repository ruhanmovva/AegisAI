import React from 'react'
import axios from 'axios'

export default function Signup({ onSuccess }: { onSuccess: ()=>void }){
  const [email,setEmail] = React.useState('')
  const [password,setPassword] = React.useState('')
  const [err,setErr] = React.useState('')

  async function handle(e:React.FormEvent){
    e.preventDefault(); setErr('')
    try{
      await axios.post('/api/auth/signup', { email, password })
      onSuccess()
    }catch(err:any){ setErr(err?.response?.data?.message || err.message) }
  }

  return (
    <form onSubmit={handle} className="space-y-4">
      <div><label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)} required /></div>
      <div><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></div>
      {err && <div className="text-red-600">{err}</div>}
      <button type="submit">Create account</button>
    </form>
  )
}
